# D-FUSS: Discrete-FoUrier SerieS

An elementary Python package to compute discrete Fourier series.